-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Jul 2023 pada 14.33
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gis-spbu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_spbu`
--

CREATE TABLE `tbl_spbu` (
  `id_spbu` int(11) NOT NULL,
  `nama_spbu` varchar(50) DEFAULT NULL,
  `no_telpon` varchar(15) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `latitude` varchar(20) DEFAULT NULL,
  `longitude` varchar(20) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_spbu`
--

INSERT INTO `tbl_spbu` (`id_spbu`, `nama_spbu`, `no_telpon`, `alamat`, `latitude`, `longitude`, `deskripsi`) VALUES
(1, 'SPBU 33-43102', '085659573835', 'Jl. Lkr. Sel., Babakan, Kec. Cisaat, Kabupaten Sukabumi, Jawa Barat 43152, Indonesia', '-6.925904284315407', '106.89519632106112', 'SPBU 33-43102\r\nJl. Lkr. Sel., Babakan, Kec. Cisaat, Kabupaten Sukabumi, Jawa Barat 43152, Indonesia'),
(2, 'Pertamina SPBU 31-43101 Otista', '085659573835', 'Jl. Otto Iskandardinata No.62, Kebonjati, Kec. Sukabumi, Kota Sukabumi, Jawa Barat 43111, Indonesia', '-6.926064382217903', '106.93315292291564', 'Pertamina\r\nJl. Otto Iskandardinata No.62, Kebonjati, Kec. Sukabumi, Kota Sukabumi, Jawa Barat 43111, Indonesia'),
(3, 'SPBU CISEUREUH WARUNG ADANG', '085659573835', '3WM5+3RP, Karang Tengah, Kec. Gunungpuyuh, Kota Sukabumi, Jawa Barat 43121, Indonesia', '-6.917048576674635', '106.9095791229154', '3WM5+3RP, Karang Tengah, Kec. Gunungpuyuh, Kota Sukabumi, Jawa Barat 43121, Indonesia'),
(4, 'SPBU Pertamina 34-43107', '085659573835', '3W8J+5R2, Gedongpanjang, Kec. Citamiang, Kota Sukabumi, Jawa Barat 43145, Indonesia', '-6.9164258885999965', '106.90998673489666', 'SPBU Pertamina 34-43107\r\n3W8J+5R2, Gedongpanjang, Kec. Citamiang, Kota Sukabumi, Jawa Barat 43145, Indonesia'),
(10, 'Pertamina 34-43104', '621500000', 'Jalan Pelabuhan II Km. 4, Cipanengah, Lembursitu, Sindangsari, Kec. Lembursitu, Kabupaten Sukabumi, Jawa Barat 43134, Indonesia', '-6.950156944097551', '106.91321055229885', 'Jalan Pelabuhan II Km. 4, Cipanengah, Lembursitu, Sindangsari, Kec. Lembursitu, Kabupaten Sukabumi, Jawa Barat 43134, Indonesia'),
(11, 'Pertamina SPBU 34-43101', '62 266 224155', '3WM6+42R, Karang Tengah, Kec. Gunungpuyuh, Kabupaten Sukabumi, Jawa Barat 43121, Indonesia', '-6.916937079596564', '106.9099542498974', 'Pertamina SPBU 34-43101'),
(12, 'Pertamina SPBU 34-43110', '62 266 239686', 'Jalan Raya Cicantayan No. 35, Cisaat, Cimahi, Kec. Cicantayan, Kabupaten Sukabumi, Jawa Barat 43152, Indonesia', '-6.905547919984478', '106.86843443455165', 'Pertamina SPBU 34-43110\r\nJalan Raya Cicantayan No. 35, Cisaat, Cimahi, Kec. Cicantayan, Kabupaten Sukabumi, Jawa Barat 43152, Indonesia'),
(13, 'SPBU 34-16702', '085659573835', '7RM9+2VQ, Jl. Raya Sukabumi, Pasir Muncang, Kec. Caringin, Kabupaten Bogor, Jawa Barat 16730, Indonesia', '-6.714169390851162', '106.81892886957952', 'SPBU 34-16702\r\n7RM9+2VQ, Jl. Raya Sukabumi, Pasir Muncang, Kec. Caringin, Kabupaten Bogor, Jawa Barat 16730, Indonesia'),
(14, 'SPBU CIAUL', '085659573835', 'Jl. R.A. Kosasih, Subangjaya, Kec. Cikole, Kota Sukabumi, Jawa Barat 43115, Indonesia', '-6.921939327205413', '106.94173002291558', 'Jl. R.A. Kosasih, Subangjaya, Kec. Cikole, Kota Sukabumi, Jawa Barat 43115, Indonesia'),
(15, 'Pertamina Jl Pelabuhan II', '085659573835', '2VQQ+P52, Jl. Pelabuhan II, Lembursitu, Kec. Lembursitu, Kabupaten Sukabumi, Jawa Barat 43169, Indonesia', '-6.960565847077072', '106.88781422106173', '2VQQ+P52, Jl. Pelabuhan II, Lembursitu, Kec. Lembursitu, Kabupaten Sukabumi, Jawa Barat 43169, Indonesia'),
(16, 'SPBU 34-43111 Baros', '085659573835', 'Jl. Baros No.234, Baros, Kec. Baros, Kota Sukabumi, Jawa Barat 43161, Indonesia', '-6.963874148985005', '106.93684590757087', 'SPBU 34-43111 Baros\r\nJl. Baros No.234, Baros, Kec. Baros, Kota Sukabumi, Jawa Barat 43161, Indonesia\r\n'),
(17, 'SPBU CIBODAS 34.4311', '62266320901', 'Jl. Pelabuhan II, Kertaraharja, Kec. Cikembar, Kabupaten Sukabumi, Jawa Barat 43157, Indonesia', '-6.977408196497241', '106.84009689553993', 'Jl. Pelabuhan II, Kertaraharja, Kec. Cikembar, Kabupaten Sukabumi, Jawa Barat 43157, Indonesia'),
(18, 'Pertamina SPBU Cipanggulaan', '62 21 1500000', 'Jl. Kompa Km. 29 Desa Bojong Kokosan Kecamatan Parungkuda, Pd. Kaso Landeuh, Kec. Parungkuda, Kabupaten Sukabumi, Jawa Barat 43357, Indonesia', '-6.821567323963052', '106.76392896524118', 'Pertamina SPBU Cipanggulaan\r\nJl. Kompa Km. 29 Desa Bojong Kokosan Kecamatan Parungkuda, Pd. Kaso Landeuh, Kec. Parungkuda, Kabupaten Sukabumi, Jawa Barat 43357, Indonesia'),
(19, 'Green Nitrogen SPBU 34 - 43101', '62 851-0079-245', 'SPBU 34 - 43101, Jalan Raya Sukaraja - Sukabumi, Karang Tengah, Gunung Puyuh, Karang Tengah, Kec. Gunungpuyuh, Kabupaten Sukabumi, Jawa Barat 43121, Indonesia', '-6.917001176651188', '106.90976706524278', 'Green Nitrogen SPBU 34 - 43101'),
(20, 'Pertamina SPBU Cipanggulaan', '62 21 1500000', 'Jl. Kompa Km. 29 Desa Bojong Kokosan Kecamatan Parungkuda, Pd. Kaso Landeuh, Kec. Parungkuda, Kabupaten Sukabumi, Jawa Barat 43357, Indonesia', '-6.821567323963052', '106.76392896524118', 'Pertamina SPBU Cipanggulaan\r\nJl. Kompa Km. 29 Desa Bojong Kokosan Kecamatan Parungkuda, Pd. Kaso Landeuh, Kec. Parungkuda, Kabupaten Sukabumi, Jawa Barat 43357, Indonesia'),
(21, 'Green Nitrogen SPBU 34 - 43101', '62 85100792450', 'SPBU 34 - 43101, Jalan Raya Sukaraja - Sukabumi, Karang Tengah, Gunung Puyuh, Karang Tengah, Kec. Gunungpuyuh, Kabupaten Sukabumi, Jawa Barat 43121, Indonesia', '-6.917001176651188', '106.90976706524278', 'Green Nitrogen SPBU 34 - 43101');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `nama_user`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_spbu`
--
ALTER TABLE `tbl_spbu`
  ADD PRIMARY KEY (`id_spbu`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_spbu`
--
ALTER TABLE `tbl_spbu`
  MODIFY `id_spbu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
