<div id="map" style="width: 100%; height: 500px;"></div>
<script>
    var map = L.map('map').setView([-6.93612495088909, 106.93025983648944], 13);

L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

<?php foreach ($spbu as $key => $value) { ?>
    L.marker([<?= $value->latitude?>, <?= $value->longitude?>])
    .bindPopup(
            "Nama SPBU : <?= $value->nama_spbu ?>
            <br>Alamat : <?=$value->alamat ?>
            <br>No telepon : <?= $value->no_telpon ?>").addTo(map);
<?php } ?>

</script>
