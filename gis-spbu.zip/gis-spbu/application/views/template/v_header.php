<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?= base_url() ?>">Webgis SPBU Kota Sukabumi</a>
        </div>

        <ul class="nav navbar-right navbar-top-links">
            
            <li class="dropdown">
                <a class="dropdown-toggle" href="<?= base_url('user/login') ?>">
                    <i class="fa fa-sign-in fa-fw"></i> Login
                </a>
                
            </li>
        </ul>