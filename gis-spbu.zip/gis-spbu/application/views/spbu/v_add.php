<div class="col-lg-7">
    <div class="panel panel-primary">
        <div class="panel-heading">
        Lokasi SPBU
        </div>
     <div class="panel-body">
<div id="map" style="width: 100%; height: 500px;"></div>
    <script>
        var map = L.map('map').setView([-6.93612495088909, 106.93025983648944], 13);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    //get koordinat
    var latInput = document.querySelector("[name=latitude]");
    var lngInput = document.querySelector("[name=longitude]");

    var curLocation = [-6.93612495088909, 106.93025983648944];
    map.attributionControl.setPrefix(false);

    var marker = new L.marker(curLocation, {
        draggable: 'true'
    });

    marker.on('dragend', function(event) {
        var position = marker.getLatLng();
        marker.setLatLng(position, {
            draggable: 'true'
        }).bindPopup(position).update();
        $("#latitude").val(position.lat);
        $("#longitude").val(position.lng);
    });

    map.addLayer(marker);

    map.on("click", function(e) {
        var lat = e.latlng.lat;
        var lng = e.latlng.lng;

        if (!marker) {
            marker = L.marker(e.latlng).addTo(map);
        } else {
            marker.setLatLng(e.latlng);
        }

        latInput.value = lat;
        lngInput.value = lng;

    });


    </script>


        </div>
    </div>
</div>

<div class="col-lg-5">
    <div class="panel panel-primary">
        <div class="panel-heading">
        Input Data SPBU
        </div>
     <div class="panel-body">
        <!-- form input data -->
        <?php echo form_open('spbu/input'); ?>
        
        <div class="form-group">
            <label>Nama SPBU</label>
            <input class="form-control" name="nama_spbu" placeholder="Nama SPBU" required>
        </div>

        <div class="form-group">
            <label>No Telepon</label>
            <input class="form-control" name="no_telpon" placeholder="No Telepon" required>
        </div>

        <div class="form-group">
            <label>Alamat</label>
            <input class="form-control" name="alamat" placeholder="Alamat" required>
        </div>

        <div class="form-group">
            <label>Latitude</label>
            <input class="form-control" id="latitude" name="latitude" placeholder="Latitude" required readonly>
        </div>

        <div class="form-group">
            <label>Longitude</label>
            <input class="form-control" id="longitude" name="logitude" placeholder="longitude" required readonly>
        </div>

        <div class="form-group">
            <label>Deskripsi</label>
            <textarea class="form-control" name="deskripsi" cols="50"></textarea>
        </div>

        <div class="form-group">
            <button class="btn btn-primary btn-sm" type="submit">Simpan</button>
            <button class="btn btn-success btn-sm" type="reset">Reset</button>
        </div>

        <?php echo 
        form_close();
        ?>
        </div>
    </div>
</div>