<div class="col-lg-12">
    <div class="panel panel-primary">
    <div class="panel-heading">
    Data SPBU Kota Sukabumi
    </div>
    <!-- /.panel-heading -->
        <div class="panel-body">
            
        <div class="table-responsive">
            <a href="<?= base_url('spbu/input')?>" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Input Data</a>
            <div><br></div>
        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama SPBU</th>
                    <th>No Telepon</th>
                    <th>Alamat</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1; foreach($spbu as $key => $value) { ?>
                <tr>
                    <td><?= $no++;?></td>
                    <td><?= $value->nama_spbu?></td>
                    <td><?= $value->no_telpon?></td>
                    <td><?= $value->alamat?></td>
                    <td><?= $value->latitude?></td>
                    <td><?= $value->longitude?></td>
                    <td>
                        <a href="" class="btn btn-success btn-sm">Edit</a>
                        <a href="" class="btn btn-danger btn-sm">Delete</a>
                    </td>
                </tr>
               <?php } ?> 
            </tbody>
        </table>
            </div>
        </div>
    </div>
</div>
