<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Spbu extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        
        $this->load->model('m_spbu');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data = array(
            'title' => 'Data SPBU Kota Sukabumi',
            'spbu' => $this->m_spbu->lists(),        
            'isi' => 'spbu/v_lists'
        );
        $this->load->view('template/v_wrapper', $data); 
    }

    public function input()
    {
        // Validasi form
        $this->form_validation->set_rules('nama_spbu', 'Nama SPBU', 'required');
        $this->form_validation->set_rules('no_telpon', 'No Telepon', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('latitude', 'Latitude', 'required');
        $this->form_validation->set_rules('longitude', 'Longitude', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == FALSE) {
            // Menampilkan form jika validasi gagal
            $data = array(
                'title' => 'Data SPBU Kota Sukabumi',
                'spbu' => $this->m_spbu->lists(),        
                'isi' => 'spbu/v_add'
            );
            $this->load->view('template/v_wrapper', $data); 
        }else {
            // Mendapatkan data dari form
            $data = array(
                'nama_spbu' => $this->input->post('nama_spbu'),
                'no_telpon' => $this->input->post('no_telpon'),
                'alamat' => $this->input->post('alamat'),
                'latitude' => $this->input->post('latitude'),
                'longitude' => $this->input->post('longitude'),
                'deskripsi' => $this->input->post('deskripsi'),
            );

            // Memasukkan data ke dalam database
            $this->m_spbu->input($data);
            $this->session->set_flashdata('pesan', 'Data Berhasil di Input');
            redirect('spbu');
        }
        }
} 

