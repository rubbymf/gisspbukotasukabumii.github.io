<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_lokasi');
        $this->load->library('googlemaps');
        

    }
    

    public function index()
    {
        $config['center'] = '-6.93612495088909, 106.93025983648944';
        $config['zoom'] = 15;
        $this->googlemaps->initialize($config); 
        $data = array(
            'title' => 'Pemetaan SPBU Kota Sukabumi',
            'map' => $this->googlemaps->create_map(),
            'spbu' => $this->m_lokasi->get_all_data(),
            'isi'     => 'v_home'
        );
        $this->load->view('template/v_wrapper', $data, FALSE);
        
    }


}

/* End of file Home.php */
