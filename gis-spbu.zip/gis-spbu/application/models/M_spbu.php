<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_spbu extends CI_Model {

    public function lists(){
        $this->db->select('*'); 
        $this->db->from('tbl_spbu');
        $this->db->order_by('id_spbu', 'desc');
        return $this->db->get()->result();
    }

    public function input($data){
        $this->db->insert('tbl_spbu', $data);
    }
}

/* End of file M_spbu.php */
